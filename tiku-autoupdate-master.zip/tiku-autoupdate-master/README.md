# tiku-autoupdate
### 网络题库暂时无法使用，现在保留最后一个版本
json版本的qg题库，方便使用jsdelivr加速，每12小时自动更新一次，不能保证完整性，[来源](http://49.235.90.76:5000/api/questions)  
